import { $, formatDateTime, safeHtml } from './utils.js';
import { loadNotifications, saveNotifications, getUnreadNotificationCount } from './storage.js';

export function createNotification({ type = 'info', title, message, code = '', read = false }) {
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    type,
    title,
    message,
    code,
    read,
    date: new Date().toISOString(),
  };
}

export function addNotification(notification) {
  const notifications = loadNotifications();
  notifications.unshift(notification);
  saveNotifications(notifications);
  return notification;
}

export function renderNotifications(container) {
  const list = typeof container === 'string' ? $(container) : container;
  if (!list) return;
  const notifications = loadNotifications();

  if (!notifications.length) {
    list.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-bell-slash"></i>
        <h3>Aucune notification pour l’instant.</h3>
        <p class="muted">Les nouvelles mises à jour apparaîtront ici.</p>
      </div>
    `;
    return;
  }

  list.innerHTML = notifications.map((item) => `
    <article class="notification-item">
      <div class="notification-icon ${item.type}"><i class="fa-solid ${iconFor(item.type)}"></i></div>
      <div class="item-content">
        <div class="item-title">${safeHtml(item.title)}</div>
        <div class="item-subtitle">${safeHtml(item.message)}</div>
        <div class="item-meta">
          <span>${formatDateTime(item.date)}</span>
          ${item.code ? `<span>Code : ${safeHtml(item.code)}</span>` : ''}
        </div>
      </div>
      <span class="status-pill ${item.type}">${item.read ? 'Lu' : 'Nouveau'}</span>
    </article>
  `).join('');
}

function iconFor(type) {
  if (type === 'success') return 'fa-circle-check';
  if (type === 'warning') return 'fa-triangle-exclamation';
  return 'fa-circle-info';
}

export function syncNotificationBadge() {
  const badge = $('#notifBadge');
  if (!badge) return;
  const unread = getUnreadNotificationCount();
  badge.textContent = String(unread);
  badge.hidden = unread === 0;
}
