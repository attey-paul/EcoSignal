import { $, safeHtml, formatDateTime } from './utils.js';
import { loadReports } from './storage.js';

let mapInstance = null;
let markerLayer = null;
let currentFilter = 'all';
const ABIDJAN_CENTER = [5.348, -4.024];

export function initMap() {
  if (mapInstance) {
    mapInstance.invalidateSize();
    return mapInstance;
  }

  const mapEl = $('#leafletMap');
  if (!mapEl || typeof L === 'undefined') return null;

  mapInstance = L.map(mapEl, {
    zoomControl: true,
    scrollWheelZoom: true,
    attributionControl: true,
  }).setView(ABIDJAN_CENTER, 12);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors',
  }).addTo(mapInstance);

  markerLayer = L.layerGroup().addTo(mapInstance);
  renderMapMarkers();
  return mapInstance;
}

export function setMapFilter(filter) {
  currentFilter = filter;
  renderMapMarkers();
}

export function renderMapMarkers() {
  if (!mapInstance || !markerLayer) return;
  markerLayer.clearLayers();
  const reports = loadReports().filter(filterReport);
  reports.forEach((report) => {
    if (!report.location || typeof report.location.lat !== 'number' || typeof report.location.lng !== 'number') return;
    const marker = L.marker([report.location.lat, report.location.lng], { icon: markerIcon(report.status) });
    const popupHtml = `
      <div style="min-width:220px">
        <strong style="display:block;margin-bottom:6px">${safeHtml(report.type)}</strong>
        <p style="margin:0 0 6px;color:#374151">${safeHtml(report.description)}</p>
        <p style="margin:0;font-size:12px;color:#6B7280">Date : ${safeHtml(formatDateTime(report.date))}</p>
        <p style="margin:4px 0 0;font-size:12px;color:#6B7280">Code : ${safeHtml(report.code)}</p>
      </div>
    `;
    marker.bindPopup(popupHtml);
    marker.addTo(markerLayer);
  });
}

function filterReport(report) {
  if (currentFilter === 'all') return true;
  return report.status === currentFilter;
}

function markerIcon(status) {
  const color = status === 'Résolu' ? '#28A745' : status === 'En cours' ? '#FD7E14' : '#DC3545';
  return L.divIcon({
    className: 'ecosignal-marker',
    html: `<div style="width:18px;height:18px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:${color};border:2px solid #fff;box-shadow:0 6px 14px rgba(15,23,42,.28);position:relative;"><div style="position:absolute;top:4px;left:4px;width:6px;height:6px;border-radius:50%;background:#fff"></div></div>`,
    iconSize: [22, 22],
    iconAnchor: [11, 22],
    popupAnchor: [0, -20],
  });
}
