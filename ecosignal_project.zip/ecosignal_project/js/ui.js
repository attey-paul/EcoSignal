import { $, $$, safeHtml, formatDate, formatDateTime, isValidImage } from './utils.js';
import { getReportCount, loadReports } from './storage.js';
import { loadNotifications, markNotificationsRead } from './storage.js';
import { renderNotifications as drawNotifications, syncNotificationBadge } from './notifications.js';
import { renderTracking } from './tracking.js';
import { setMapFilter, renderMapMarkers, initMap } from './map.js';
import { getCurrentPosition } from './geolocation.js';
import { createReport, saveReport, saveNotification, getReportByCode } from './storage.js';
import { createNotification } from './notifications.js';
import { copyToClipboard, sanitizeString } from './utils.js';

export const state = {
  route: 'splash',
  lastCreatedCode: '',
  selectedPhoto: '',
  selectedLocation: null,
  mapFilter: 'all',
};

export function bindUi() {
  $('#startBtn')?.addEventListener('click', () => navigate('home'));
  $('#notifBtn')?.addEventListener('click', () => navigate('notifications'));
  $('#themeToggleBtn')?.addEventListener('click', toggleTheme);
  $('#homeStats') && updateHomeStats();

  $$('.feature-card,[data-navigate],.nav-link').forEach((el) => {
    el.addEventListener('click', () => {
      const route = el.dataset.navigate;
      if (route) navigate(route);
    });
  });

  $('#locateBtn')?.addEventListener('click', async () => {
    const result = await getCurrentPosition();
    state.selectedLocation = result;
    updateLocationUI(result);
    showToast(result.error ? 'localisation' : 'géolocalisation', result.error ? 'Position estimée utilisée.' : 'Position récupérée avec succès.', result.error ? 'info' : 'success');
  });

  $('#photoInput')?.addEventListener('change', handlePhotoUpload);
  $('#description')?.addEventListener('input', updateCounter);
  $('#reportForm')?.addEventListener('submit', handleSubmitReport);
  $('#resetReportBtn')?.addEventListener('click', resetReportForm);
  $('#shareReportBtn')?.addEventListener('click', shareCurrentCode);
  $('#trackFromConfirmBtn')?.addEventListener('click', () => navigate('tracking', { code: state.lastCreatedCode }));
  $('#trackingSearchBtn')?.addEventListener('click', searchTracking);
  $('#trackingCodeInput')?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); searchTracking(); } });
  $('#markAllReadBtn')?.addEventListener('click', () => { markNotificationsRead(); syncNotificationBadge(); drawNotifications('#notificationsList'); showToast('notifications', 'Toutes les notifications ont été marquées comme lues.', 'success'); });

  $$('.segmented-btn').forEach((button) => {
    button.addEventListener('click', () => {
      $$('.segmented-btn').forEach((btn) => btn.classList.remove('is-active'));
      button.classList.add('is-active');
      state.mapFilter = button.dataset.mapFilter;
      setMapFilter(state.mapFilter);
      renderMapMarkers();
    });
  });

  updateHomeStats();
  syncNotificationBadge();
}

export function navigate(route, params = {}) {
  const target = route || 'splash';
  const hash = new URLSearchParams(params).toString();
  location.hash = hash ? `#${target}?${hash}` : `#${target}`;
}

export function renderRoute(route, params = {}) {
  state.route = route;
  $$('.view').forEach((view) => view.classList.remove('is-active'));
  const view = $(`#view-${route}`);
  if (view) view.classList.add('is-active');

  $$('.nav-link').forEach((nav) => nav.classList.toggle('is-active', nav.dataset.navigate === route));

  if (route === 'splash') {
    updateHomeStats();
  }
  if (route === 'home') {
    renderRecentReports();
    updateHomeStats();
  }
  if (route === 'report') {
    updateLocationUI(state.selectedLocation);
    updateCounter();
  }
  if (route === 'map') {
    initMap();
    renderMapSection();
  }
  if (route === 'tracking') {
    const code = params.code || state.lastCreatedCode || $('#trackingCodeInput')?.value;
    if (code && $('#trackingCodeInput')) $('#trackingCodeInput').value = code;
    renderTrackingSection(code);
  }
  if (route === 'notifications') {
    drawNotifications('#notificationsList');
    syncNotificationBadge();
    markNotificationsRead();
  }
  requestAnimationFrame(() => $('#appMain')?.focus());
}

export function updateHomeStats() {
  const reports = getReportCount();
  const notifications = loadNotifications().filter((item) => !item.read).length;
  const node = $('#homeStats');
  if (node) node.textContent = `${reports} signalement${reports > 1 ? 's' : ''} · ${notifications} notification${notifications > 1 ? 's' : ''} non lue${notifications > 1 ? 's' : ''}`;
}

export function renderRecentReports() {
  const container = $('#recentReportsList');
  if (!container) return;
  const reports = loadReports().slice(0, 3);
  container.innerHTML = reports.map(reportCard).join('');
}

export function renderMapSection() {
  const list = $('#mapReportsList');
  if (list) list.innerHTML = loadReports().slice(0, 6).map(reportCard).join('');
  renderMapMarkers();
}

export function renderTrackingSection(code) {
  renderTracking(code, '#trackingResultPanel');
}

export function updateLocationUI(location) {
  const title = $('#locationLabel');
  const details = $('#locationDetails');
  if (!title || !details) return;

  if (!location) {
    title.textContent = 'En attente de géolocalisation…';
    details.textContent = 'Autorisez la géolocalisation pour affiner votre position.';
    return;
  }

  const quartier = sanitizeString(location.quartier || location.label || 'Abidjan');
  title.textContent = `${quartier}, Abidjan`;
  details.textContent = location.error
    ? `Position estimée. ${location.error}`
    : `Ville : Abidjan · Coordonnées : ${location.lat.toFixed(5)}, ${location.lng.toFixed(5)}${location.accuracy ? ` · Précision ±${Math.round(location.accuracy)} m` : ''}`;
}

function updateCounter() {
  const textarea = $('#description');
  const counter = $('#descCounter');
  if (!textarea || !counter) return;
  counter.textContent = `${textarea.value.length} / 800`;
}

async function handlePhotoUpload(event) {
  const input = event.currentTarget;
  const file = input.files?.[0];
  const preview = $('#photoPreview');
  if (!preview) return;
  if (!file) {
    state.selectedPhoto = '';
    preview.innerHTML = '<span class="photo-placeholder"><i class="fa-regular fa-image"></i> Aperçu instantané</span>';
    return;
  }
  const validation = isValidImage(file);
  if (!validation.ok) {
    showToast('photo', validation.message, 'error');
    input.value = '';
    return;
  }
  const dataUrl = await toDataUrl(file);
  state.selectedPhoto = dataUrl;
  preview.innerHTML = `<img src="${dataUrl}" alt="Aperçu de la photo envoyée" loading="lazy" />`;
}

function toDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

async function handleSubmitReport(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const type = $('#problemType')?.value;
  const description = $('#description')?.value?.trim() || '';
  const customLocation = $('#customLocation')?.value?.trim() || '';

  const errors = validateForm({ type, description, photo: state.selectedPhoto });
  if (errors.length) {
    showToast('form', errors[0], 'error');
    return;
  }

  const report = createReport({
    type,
    description,
    photo: state.selectedPhoto,
    location: state.selectedLocation,
    customLocation,
  });

  saveReport(report);
  saveNotification(createNotification({ type: 'info', title: 'Votre signalement a été reçu.', message: `Le dossier ${report.code} a été enregistré.`, code: report.code }));
  state.lastCreatedCode = report.code;
  $('#generatedCode').textContent = report.code;
  updateHomeStats();
  renderRecentReports();
  syncNotificationBadge();
  form.reset();
  state.selectedPhoto = '';
  state.selectedLocation = null;
  updateLocationUI(null);
  const preview = $('#photoPreview');
  if (preview) preview.innerHTML = '<span class="photo-placeholder"><i class="fa-regular fa-image"></i> Aperçu instantané</span>';
  navigate('confirmation');
  showToast('report', 'Signalement enregistré avec succès.', 'success');
}

function validateForm({ type, description, photo }) {
  const errors = [];
  if (!type) errors.push('Veuillez sélectionner un type de problème.');
  if (!description || description.length < 20) errors.push('La description doit contenir au moins 20 caractères.');
  const imageValidation = isValidImage(photo ? { type: 'image/jpeg', size: 0 } : null);
  if (!imageValidation.ok) errors.push(imageValidation.message);
  return errors;
}

function resetReportForm() {
  $('#reportForm')?.reset();
  state.selectedPhoto = '';
  state.selectedLocation = null;
  const preview = $('#photoPreview');
  if (preview) preview.innerHTML = '<span class="photo-placeholder"><i class="fa-regular fa-image"></i> Aperçu instantané</span>';
  updateLocationUI(null);
  updateCounter();
}

async function shareCurrentCode() {
  const code = state.lastCreatedCode;
  if (!code) {
    showToast('share', 'Aucun code à partager pour le moment.', 'info');
    return;
  }

  const text = `Mon code de suivi EcoSignal : ${code}`;
  const shareData = { title: 'EcoSignal', text };
  if (navigator.share) {
    try {
      await navigator.share(shareData);
      showToast('share', 'Partage envoyé.', 'success');
      return;
    } catch (_) {}
  }

  const copied = await copyToClipboard(text);
  if (copied) {
    showToast('share', 'Code copié. Vous pouvez le coller dans WhatsApp.', 'success');
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  } else {
    showToast('share', 'Impossible de partager automatiquement.', 'error');
  }
}

function searchTracking() {
  const code = $('#trackingCodeInput')?.value.trim();
  renderTrackingSection(code);
  if (code && getReportByCode(code)) {
    showToast('tracking', 'Signalement trouvé.', 'success');
  } else {
    showToast('tracking', 'Code introuvable.', 'error');
  }
}

function reportCard(report) {
  const statusClass = report.status === 'Résolu' ? 'resolved' : report.status === 'En cours' ? 'processing' : 'received';
  const icon = report.status === 'Résolu' ? 'fa-circle-check' : report.status === 'En cours' ? 'fa-spinner' : 'fa-triangle-exclamation';
  return `
    <article class="report-item">
      <div class="report-badge ${statusClass}"><i class="fa-solid ${icon}"></i></div>
      <div class="item-content">
        <div class="item-title">${safeHtml(report.type)}</div>
        <div class="item-subtitle">${safeHtml(report.description)}</div>
        <div class="item-meta">
          <span>${safeHtml(report.code)}</span>
          <span>${formatDate(report.date)}</span>
          <span>${safeHtml(report.location?.label || report.location?.quartier || 'Abidjan')}</span>
        </div>
      </div>
      <span class="status-pill ${statusClass}">${safeHtml(report.status)}</span>
    </article>
  `;
}

function toggleTheme() {
  const body = document.body;
  const nextTheme = body.dataset.theme === 'dark' ? 'light' : 'dark';
  body.dataset.theme = nextTheme;
  localStorage.setItem('ecosignal_theme', nextTheme);
  showToast('theme', nextTheme === 'dark' ? 'Thème sombre activé.' : 'Thème clair activé.', 'info');
}

export function hydrateTheme() {
  const saved = localStorage.getItem('ecosignal_theme');
  if (saved) document.body.dataset.theme = saved;
}

export function showToast(title, message, type = 'info') {
  const host = $('#toastHost');
  if (!host) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <i class="fa-solid ${toastIcon(type)}"></i>
    <div>
      <strong>${safeHtml(title)}</strong>
      <p>${safeHtml(message)}</p>
    </div>
  `;
  host.appendChild(toast);
  window.setTimeout(() => toast.remove(), 3200);
}

function toastIcon(type) {
  if (type === 'success') return 'fa-circle-check';
  if (type === 'error') return 'fa-circle-xmark';
  return 'fa-circle-info';
}
