import { YEAR, generateTrackingCode, sanitizeString, createId } from './utils.js';

const KEYS = {
  reports: 'ecosignal_reports',
  notifications: 'ecosignal_notifications',
  settings: 'ecosignal_settings',
};

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function demoReports() {
  return [
    {
      id: createId('report'),
      code: `ECO-${YEAR}-A7X3`,
      date: new Date(Date.now() - 2 * 86400000).toISOString(),
      type: 'Dépôt sauvage',
      description: 'Accumulation importante de sacs et déchets ménagers près du carrefour principal.',
      photo: '',
      status: 'Reçu',
      location: { lat: 5.418, lng: -4.026, label: 'Abobo', city: 'Abidjan', quartier: 'Abobo' },
      history: historySeed('Reçu', 'Assigné', 'En cours', 'Résolu').slice(0, 1),
      read: true,
    },
    {
      id: createId('report'),
      code: `ECO-${YEAR}-B4R1`,
      date: new Date(Date.now() - 86400000).toISOString(),
      type: 'Caniveau bouché',
      description: 'Eaux stagnantes et obstruction partielle du drainage après de fortes pluies.',
      photo: '',
      status: 'En cours',
      location: { lat: 5.304, lng: -4.015, label: 'Treichville', city: 'Abidjan', quartier: 'Treichville' },
      history: historySeed('Reçu', 'Assigné', 'En cours', 'Résolu').slice(0, 3),
      read: true,
    },
    {
      id: createId('report'),
      code: `ECO-${YEAR}-C2M5`,
      date: new Date(Date.now() - 4 * 86400000).toISOString(),
      type: 'Déchets dangereux',
      description: 'Présence de déchets potentiellement dangereux devant un terrain vague.',
      photo: '',
      status: 'Résolu',
      location: { lat: 5.326, lng: -4.089, label: 'Yopougon', city: 'Abidjan', quartier: 'Yopougon' },
      history: historySeed('Reçu', 'Assigné', 'En cours', 'Résolu'),
      read: true,
    },
  ];
}

function historySeed(...labels) {
  const base = Date.now() - labels.length * 86400000;
  return labels.map((label, index) => ({
    status: label,
    date: new Date(base + index * 86400000).toISOString(),
    note: label,
  }));
}

function demoNotifications() {
  return [
    { id: createId('notif'), type: 'info', title: 'Votre signalement a été reçu.', message: 'Notre équipe a bien enregistré votre dossier.', date: new Date(Date.now() - 2 * 86400000).toISOString(), read: false, code: `ECO-${YEAR}-A7X3` },
    { id: createId('notif'), type: 'warning', title: 'Votre signalement est en cours.', message: 'Une équipe de traitement a été assignée.', date: new Date(Date.now() - 86400000).toISOString(), read: false, code: `ECO-${YEAR}-B4R1` },
    { id: createId('notif'), type: 'success', title: 'Votre signalement est résolu.', message: 'L’intervention a été clôturée avec succès.', date: new Date(Date.now() - 3 * 86400000).toISOString(), read: true, code: `ECO-${YEAR}-C2M5` },
  ];
}

function demoSettings() {
  return { theme: 'light', pwaReady: true, createdAt: new Date().toISOString() };
}

function ensureSeeded() {
  const reports = readJSON(KEYS.reports, null);
  if (!Array.isArray(reports) || reports.length === 0) writeJSON(KEYS.reports, demoReports());
  const notifications = readJSON(KEYS.notifications, null);
  if (!Array.isArray(notifications) || notifications.length === 0) writeJSON(KEYS.notifications, demoNotifications());
  const settings = readJSON(KEYS.settings, null);
  if (!settings) writeJSON(KEYS.settings, demoSettings());
}

export function initStorage() {
  ensureSeeded();
}

export function loadReports() {
  ensureSeeded();
  return readJSON(KEYS.reports, []);
}

export function saveReports(reports) {
  writeJSON(KEYS.reports, reports);
}

export function saveReport(report) {
  const reports = loadReports();
  reports.unshift(report);
  saveReports(reports);
  return report;
}

export function loadNotifications() {
  ensureSeeded();
  return readJSON(KEYS.notifications, []);
}

export function saveNotifications(notifications) {
  writeJSON(KEYS.notifications, notifications);
}

export function saveNotification(notification) {
  const notifications = loadNotifications();
  notifications.unshift(notification);
  saveNotifications(notifications);
  return notification;
}

export function loadSettings() {
  ensureSeeded();
  return readJSON(KEYS.settings, demoSettings());
}

export function saveSettings(settings) {
  writeJSON(KEYS.settings, settings);
}

export function createReport({ type, description, photo, location, customLocation }) {
  const existingCodes = loadReports().map((r) => r.code);
  const code = generateTrackingCode(existingCodes);
  const now = new Date().toISOString();
  const quartier = sanitizeString(customLocation || location?.quartier || location?.label || 'Abidjan');

  return {
    id: createId('report'),
    code,
    date: now,
    type: sanitizeString(type),
    description: sanitizeString(description),
    photo: photo || '',
    status: 'Reçu',
    location: {
      lat: location?.lat ?? null,
      lng: location?.lng ?? null,
      label: quartier,
      quartier,
      city: 'Abidjan',
      source: location?.source || 'geolocation',
      accuracy: location?.accuracy ?? null,
    },
    history: [
      { status: 'Reçu', date: now, note: 'Signalement reçu' },
      { status: 'Assigné', date: null, note: 'En attente d’assignation' },
      { status: 'En cours', date: null, note: 'En attente de traitement' },
      { status: 'Résolu', date: null, note: 'En attente de résolution' },
    ],
    read: false,
  };
}

export function getReportByCode(code) {
  if (!code) return null;
  const target = sanitizeString(code).toUpperCase();
  return loadReports().find((report) => report.code.toUpperCase() === target) || null;
}

export function updateReportStatus(code, status) {
  const reports = loadReports();
  const report = reports.find((item) => item.code === code);
  if (!report) return null;
  report.status = status;
  const idx = ['Reçu', 'Assigné', 'En cours', 'Résolu'].indexOf(status);
  report.history = report.history.map((step, index) => index <= idx ? { ...step, date: step.date || new Date().toISOString() } : step);
  saveReports(reports);
  return report;
}

export function markNotificationsRead() {
  const notifications = loadNotifications().map((notif) => ({ ...notif, read: true }));
  saveNotifications(notifications);
}

export function getUnreadNotificationCount() {
  return loadNotifications().filter((item) => !item.read).length;
}

export function getReportCount() {
  return loadReports().length;
}
