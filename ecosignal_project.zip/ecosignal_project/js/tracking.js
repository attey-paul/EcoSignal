import { $, safeHtml, formatDateTime } from './utils.js';
import { getReportByCode } from './storage.js';

const STEP_META = [
  { key: 'Reçu', label: 'Signalement reçu', description: 'Le dossier a été enregistré dans le système.' },
  { key: 'Assigné', label: 'Assigné', description: 'Une équipe a été affectée au traitement.' },
  { key: 'En cours', label: 'En cours', description: 'L’intervention est en cours de traitement.' },
  { key: 'Résolu', label: 'Résolu', description: 'Le problème a été traité et clôturé.' },
];

export function renderTracking(code, container) {
  const target = typeof container === 'string' ? $(container) : container;
  if (!target) return;

  const report = getReportByCode(code);
  if (!report) {
    target.innerHTML = `
      <div class="empty-state">
        <i class="fa-regular fa-circle-xmark"></i>
        <h3>Code introuvable</h3>
        <p class="muted">Vérifiez le code saisi puis réessayez.</p>
      </div>
    `;
    return;
  }

  const activeIndex = STEP_META.findIndex((step) => step.key === report.status);
  target.innerHTML = `
    <article class="tracking-item">
      <div class="item-content">
        <div class="item-title">${safeHtml(report.type)}</div>
        <div class="item-subtitle">${safeHtml(report.description)}</div>
        <div class="item-meta">
          <span>Code : ${safeHtml(report.code)}</span>
          <span>${formatDateTime(report.date)}</span>
          <span>${safeHtml(report.location?.label || report.location?.quartier || 'Abidjan')}</span>
        </div>
      </div>
      <span class="status-pill ${statusClass(report.status)}">${safeHtml(report.status)}</span>
    </article>
    <div class="timeline" aria-label="Timeline du signalement">
      ${STEP_META.map((step, index) => {
        const state = index < activeIndex ? 'done' : index === activeIndex ? 'current' : 'pending';
        const cardActive = state !== 'pending' ? 'active' : '';
        const dateLabel = report.history?.[index]?.date ? formatDateTime(report.history[index].date) : 'En attente';
        return `
          <div class="timeline-step">
            <div class="timeline-dot ${state}">${index + 1}</div>
            <div class="timeline-card ${cardActive}">
              <h4>${safeHtml(step.label)}</h4>
              <p>${safeHtml(step.description)}</p>
              <div class="timeline-date">${safeHtml(dateLabel)}</div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function statusClass(status) {
  if (status === 'Résolu') return 'resolved';
  if (status === 'En cours' || status === 'Assigné') return 'processing';
  return 'received';
}
