import { initStorage, loadReports } from './storage.js';
import { hydrateTheme, bindUi, renderRoute, updateHomeStats, renderRecentReports, renderMapSection, renderTrackingSection, updateLocationUI, showToast } from './ui.js';
import { initRouter } from './router.js';
import { syncNotificationBadge, renderNotifications } from './notifications.js';
import { initMap } from './map.js';
import { $, $$ } from './utils.js';

function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js').catch(() => {});
  }
}

function boot() {
  initStorage();
  hydrateTheme();
  bindUi();
  updateHomeStats();
  renderRecentReports();
  syncNotificationBadge();

  const router = initRouter((route, params) => {
    renderRoute(route, params);
    if (route === 'map') {
      requestAnimationFrame(() => initMap());
    }
    if (route === 'notifications') renderNotifications('#notificationsList');
    if (route === 'home') renderRecentReports();
    if (route === 'tracking' && params.code) renderTrackingSection(params.code);
  });

  if (!location.hash) router.go('splash');

  $('#reportForm')?.addEventListener('invalid', (event) => {
    event.preventDefault();
  }, true);

  $$('.nav-link, [data-navigate]').forEach((el) => el.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      el.click();
    }
  }));

  setTimeout(() => {
    if (location.hash === '#splash') {
      showToast('EcoSignal', 'Application prête à l’emploi.', 'success');
    }
  }, 450);

  const reports = loadReports();
  if (reports.length === 0) {
    updateLocationUI(null);
  }

  registerServiceWorker();
}

document.addEventListener('DOMContentLoaded', boot);
