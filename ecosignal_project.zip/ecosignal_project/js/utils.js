export const YEAR = new Date().getFullYear();

export const $ = (selector, parent = document) => parent.querySelector(selector);
export const $$ = (selector, parent = document) => Array.from(parent.querySelectorAll(selector));

export function safeHtml(input = '') {
  return DOMPurify.sanitize(String(input), { ALLOWED_TAGS: [], ALLOWED_ATTR: [] });
}

export function formatDate(dateInput, options = {}) {
  const date = dateInput instanceof Date ? dateInput : new Date(dateInput);
  if (Number.isNaN(date.getTime())) return '';
  return new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit', month: 'short', year: 'numeric', ...options,
  }).format(date);
}

export function formatDateTime(dateInput) {
  const date = dateInput instanceof Date ? dateInput : new Date(dateInput);
  if (Number.isNaN(date.getTime())) return '';
  return new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  }).format(date);
}

export function formatCoordinates({ lat, lng } = {}) {
  if (typeof lat !== 'number' || typeof lng !== 'number') return 'Coordonnées indisponibles';
  return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
}

export function generateTrackingCode(existing = []) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const taken = new Set(existing);
  let code = '';
  do {
    const random = crypto.getRandomValues(new Uint32Array(4));
    const suffix = Array.from({ length: 4 }, (_, i) => alphabet[random[i] % alphabet.length]).join('');
    code = `ECO-${YEAR}-${suffix}`;
  } while (taken.has(code));
  return code;
}

export async function copyToClipboard(text) {
  const value = String(text ?? '');
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      return true;
    }
  } catch (_) {}
  const input = document.createElement('input');
  input.value = value;
  document.body.appendChild(input);
  input.select();
  const ok = document.execCommand('copy');
  document.body.removeChild(input);
  return ok;
}

export function escapeRegExp(value = '') {
  return String(value).replace(/[.*+?^${}()|[\]\]/g, '\$&');
}

export function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

export function createId(prefix = 'id') {
  const bytes = crypto.getRandomValues(new Uint32Array(2));
  return `${prefix}-${bytes[0].toString(36)}-${bytes[1].toString(36)}`;
}

export function isValidImage(file) {
  if (!file) return { ok: true };
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
  if (!allowedTypes.includes(file.type)) {
    return { ok: false, message: 'Format invalide. Utilisez JPG, PNG ou WEBP.' };
  }
  const max = 5 * 1024 * 1024;
  if (file.size > max) {
    return { ok: false, message: 'Image trop lourde. La limite est de 5 Mo.' };
  }
  return { ok: true };
}

export function sanitizeString(value, fallback = '') {
  const clean = safeHtml(String(value ?? '').trim());
  return clean || fallback;
}

export function nearestNeighborhood(lat, lng) {
  const neighborhoods = [
    { name: 'Abobo', lat: 5.418, lng: -4.026 },
    { name: 'Yopougon', lat: 5.326, lng: -4.089 },
    { name: 'Adjamé', lat: 5.366, lng: -4.019 },
    { name: 'Cocody', lat: 5.348, lng: -3.998 },
    { name: 'Plateau', lat: 5.320, lng: -4.024 },
    { name: 'Marcory', lat: 5.302, lng: -3.983 },
    { name: 'Treichville', lat: 5.304, lng: -4.015 },
    { name: 'Koumassi', lat: 5.289, lng: -3.972 },
  ];
  const distance = (a, b) => {
    const R = 6371;
    const toRad = (n) => (n * Math.PI) / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(h));
  };
  return neighborhoods.reduce((best, n) => {
    const d = distance({ lat, lng }, n);
    return d < best.d ? { ...n, d } : best;
  }, { name: 'Abidjan', d: Infinity }).name;
}

export function createSafeText(text) {
  const span = document.createElement('span');
  span.textContent = text;
  return span;
}
