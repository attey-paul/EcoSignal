import { navigate as navigateUi } from './ui.js';

export function initRouter(onRouteChange) {
  const parse = () => {
    const raw = location.hash.replace(/^#/, '') || 'splash';
    const [route, queryString] = raw.split('?');
    const params = Object.fromEntries(new URLSearchParams(queryString || ''));
    return { route: route || 'splash', params };
  };

  const handle = () => {
    const { route, params } = parse();
    onRouteChange(route, params);
  };

  window.addEventListener('hashchange', handle);
  handle();

  return {
    go(route, params = {}) { navigateUi(route, params); },
    current() { return parse(); },
  };
}
