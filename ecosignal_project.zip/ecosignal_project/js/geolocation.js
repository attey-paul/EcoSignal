import { nearestNeighborhood } from './utils.js';

const ABIDJAN_FALLBACK = {
  lat: 5.316666,
  lng: -4.033333,
  accuracy: null,
  label: 'Abidjan',
  quartier: 'Plateau',
  city: 'Abidjan',
  source: 'fallback',
};

export function getCurrentPosition() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve({ ...ABIDJAN_FALLBACK, label: 'Géolocalisation indisponible' });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        const quartier = nearestNeighborhood(latitude, longitude);
        resolve({ lat: latitude, lng: longitude, accuracy, quartier, city: 'Abidjan', label: quartier, source: 'navigator' });
      },
      (error) => {
        const message = error?.message || 'Impossible de récupérer la position.';
        resolve({ ...ABIDJAN_FALLBACK, error: message });
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 120000 }
    );
  });
}
