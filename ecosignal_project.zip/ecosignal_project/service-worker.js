const CACHE_NAME = 'ecosignal-v1';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/reset.css',
  './css/variables.css',
  './css/style.css',
  './css/animations.css',
  './css/responsive.css',
  './js/app.js',
  './js/router.js',
  './js/ui.js',
  './js/storage.js',
  './js/geolocation.js',
  './js/map.js',
  './js/notifications.js',
  './js/tracking.js',
  './js/utils.js',
  './assets/logo.svg',
  './assets/illustrations/splash-hero.svg',
  './assets/illustrations/confirmation.svg'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {
      const clone = response.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
      return response;
    }).catch(() => caches.match('./index.html')))
  );
});
